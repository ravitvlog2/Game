package com.aadevelopers.cashking.csm.adapter;

import static com.aadevelopers.cashking.Just_base.addPoint;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_KEY;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_Value;
import static com.aadevelopers.cashking.helper.Constatnt.Base_Url;
import static com.aadevelopers.cashking.helper.PrefManager.Add_Coins_;


import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.adcolony.sdk.AdColony;
import com.adcolony.sdk.AdColonyAdOptions;
import com.adcolony.sdk.AdColonyInterstitial;
import com.adcolony.sdk.AdColonyInterstitialListener;
import com.adcolony.sdk.AdColonyReward;
import com.adcolony.sdk.AdColonyRewardListener;
import com.adcolony.sdk.AdColonyZone;
import com.adgatemedia.sdk.classes.AdGateMedia;
import com.adgatemedia.sdk.network.OnOfferWallLoadFailed;
import com.adgatemedia.sdk.network.OnOfferWallLoadSuccess;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.ayetstudios.publishersdk.AyetSdk;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.RewardedVideoAd;
import com.facebook.ads.RewardedVideoAdListener;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.ironsource.mediationsdk.model.Placement;
import com.ironsource.mediationsdk.sdk.OfferwallListener;
import com.ironsource.mediationsdk.sdk.RewardedVideoListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.offertoro.sdk.interfaces.OfferWallListener;
import com.offertoro.sdk.sdk.OffersInit;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;
import com.aadevelopers.cashking.R;
import com.aadevelopers.cashking.helper.AppController;
import com.aadevelopers.cashking.helper.JsonRequest;
import com.aadevelopers.cashking.csm.model.OfferWall_Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class OfferWall_Adapter extends RecyclerView.Adapter<OfferWall_Adapter.ViewHolder> {
    public List<OfferWall_Model> offer_data;
    public Context context;
    String ADGET_WALL_id;
    Boolean check = false;
    RewardedVideoAd rewardedVideoAd;
    IUnityAdsLoadListener loadListener;
    IUnityAdsShowListener showListener;

    AdColonyInterstitial rewardAdColony;
    Boolean isRewardLoaded = false;
    AdColonyInterstitialListener rewardListener;
    AdColonyAdOptions rewardAdOptions;

    public OfferWall_Adapter(List<OfferWall_Model> offer_data, Context context) {

        this.offer_data = offer_data;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_offerwall, parent, false);
        return new ViewHolder(view);
    }
    @NonNull

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final OfferWall_Model offer = offer_data.get(position);

        android.app.Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.loading);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable
                (Color.TRANSPARENT));

     Glide.with(context).load(offer.getImage())
                .apply(new RequestOptions().placeholder(R.mipmap.ic_launcher_round))
                .into(holder.img);

     holder.title.setText(offer.getTitle());

        int randomNum = ThreadLocalRandom.current().nextInt(10, 20 + 1);
        holder.k.setText(randomNum+"k");

        if (offer.getType().equals("adget"))
        {
            settings();
        }
        if (offer.getType().equals("colony"))
        {
            initRewardedAd();
        }
        if (offer.getType().equals("iron"))
        {
            holder.k.setText("5+");


        }

        if (offer.getType().equals("iron")||offer.getType().equals("fb")||offer.getType().equals("unity")||
                offer.getType().equals("start")||
                offer.getType().equals("colony"))
        {
            holder.k.setText("5+");

        }

        if (offer.getType().equals("iron_offer"))
        {
            IronSource.setOfferwallListener(new OfferwallListener() {
                @Override
                public void onOfferwallAvailable(boolean isAvailable) {

                }
                @Override
                public void onOfferwallOpened() {
                }
                @Override
                public void onOfferwallShowFailed(IronSourceError error) {
                }

                @Override
                public boolean onOfferwallAdCredited(int credits, int totalCredits, boolean totalCreditsFlag) {
                    return true;
                }

                @Override
                public void onGetOfferwallCreditsFailed(IronSourceError error) {
                }

                @Override
                public void onOfferwallClosed() {
                }
            });

        }





        holder.click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (offer.getType().equals("adget"))
                {   dialog.show();
                    final HashMap<String, String> subids = new HashMap<String, String>();
                    subids.put("s2", "my sub id");
                    AdGateMedia adGateMedia = AdGateMedia.getInstance();
                    adGateMedia.loadOfferWall(context,
                            ADGET_WALL_id,
                            AppController.getInstance().getId(),
                            subids,
                            new OnOfferWallLoadSuccess() {
                                @Override
                                public void onOfferWallLoadSuccess() {
                                    dialog.dismiss();
                                    // Here you can call adGateMedia.showOfferWall();
                                    AdGateMedia.getInstance().showOfferWall(context,
                                            new AdGateMedia.OnOfferWallClosed() {
                                                @Override
                                                public void onOfferWallClosed() {
                                                    // Here you handle the 'Offer wall has just been closed' event
                                                }
                                            });
                                }
                            },
                            new OnOfferWallLoadFailed() {
                                @Override
                                public void onOfferWallLoadFailed(String reason) {
                                    // Here you handle the errors with provided reason
                                    dialog.dismiss();

                                }
                            });
                }
                else if (offer.getType().equals("toro"))
                {
                    dialog.show();
                    OffersInit.getInstance().create((Activity) context);
                    OffersInit.getInstance().setOfferWallListener(new OfferWallListener() {
                        @Override
                        public void onOTOfferWallInitSuccess() {
                            OffersInit.getInstance().showOfferWall((Activity) context);
                            dialog.dismiss();
                        }

                        @Override
                        public void onOTOfferWallInitFail(String s) {
                            Toast.makeText(context, s.trim(), Toast.LENGTH_SHORT).show();
                            dialog.dismiss();

                        }

                        @Override
                        public void onOTOfferWallOpened() {

                        }

                        @Override
                        public void onOTOfferWallCredited(double v, double v1) {

                        }

                        @Override
                        public void onOTOfferWallClosed() {

                        }
                    });
                }
                else if (offer.getType().equals("ayet"))
                {
                    holder.k.setText("5+");
                    if (AyetSdk.isInitialized()) {
                        AyetSdk.showOfferwall((Application) context.getApplicationContext(), context.getString(R.string.AYET_ADSLOT));

                    }else
                    {
                        Toast.makeText(context, "Failed to load offerwall try again later.", Toast.LENGTH_SHORT).show();
                    }
                    AyetSdk.showOfferwall((Application) context.getApplicationContext(), context.getString(R.string.AYET_ADSLOT));
                }
                else if (offer.getType().equals("fb"))
                {   dialog.show();
                    holder.k.setText("5+");
                    rewardedVideoAd = new RewardedVideoAd(context, context.getString(R.string.FB_Rewarded_Ad_Unit));
                    RewardedVideoAdListener rewardedVideoAdListener = new RewardedVideoAdListener() {

                        @Override
                        public void onRewardedVideoCompleted() {
                            check = true;


                        }

                        @Override
                        public void onLoggingImpression(Ad ad) {

                        }

                        @Override
                        public void onRewardedVideoClosed() {
                            if (check) {
                               // Random r = new Random();
                               // int i1 = r.nextInt(max - min) + min;
                                String point = "5";
                                Add_Coins_(context,point,"Video credit");
                                check = false;

                            }



                        }

                        @Override
                        public void onError(Ad ad, AdError adError) {
                            dialog.dismiss();

                        }

                        @Override
                        public void onAdLoaded(Ad ad) {
                            // Rewarded video ad is loaded and ready to be displayed
                            dialog.dismiss();
                            rewardedVideoAd.show();

                        }

                        @Override
                        public void onAdClicked(Ad ad) {

                        }

                    };
                    rewardedVideoAd.loadAd(
                            rewardedVideoAd.buildLoadAdConfig()
                                    .withAdListener(rewardedVideoAdListener)
                                    .build());

                }
                else if (offer.getType().equals("iron"))
                {

                    IronSource.setRewardedVideoListener(new RewardedVideoListener() {
                        @Override
                        public void onRewardedVideoAdOpened() {
                        }
                        /*Invoked when the RewardedVideo ad view is about to be closed.
                        Your activity will now regain its focus.*/
                        @Override
                        public void onRewardedVideoAdClosed() {
                            Toast.makeText(context, "Coins added", Toast.LENGTH_SHORT).show();
                        }
                        @Override
                        public void onRewardedVideoAvailabilityChanged(boolean available) {
                            //Change the in-app 'Traffic Driver' state according to availability.

                        }

                        @Override
                        public void onRewardedVideoAdRewarded(Placement placement) {
                            String point = "5";
                           // Add_Coins_(context,point,"Video credit");
                            addPoint(context, point, "Video credit");

                        }

                        @Override
                        public void onRewardedVideoAdShowFailed(IronSourceError error) {

                        }

                        @Override
                        public void onRewardedVideoAdClicked(Placement placement){
                        }

                        @Override
                        public void onRewardedVideoAdStarted(){
                        }

                        @Override
                        public void onRewardedVideoAdEnded(){
                        }
                    });

                    if (IronSource.isRewardedVideoAvailable())
                    {
                        IronSource.showRewardedVideo();
                    }else
                    {
                        Toast.makeText(context, "Video not available!", Toast.LENGTH_SHORT).show();
                    }
                }

                else if (offer.getType().equals("iron_offer"))
                {

                    if (IronSource.isOfferwallAvailable())
                    {
                        IronSource.showOfferwall();
                    }else
                    {
                        Toast.makeText(context, "Video not available!", Toast.LENGTH_SHORT).show();
                    }
                }

                else if (offer.getType().equals("unity"))
                {   UnityAds.load(context.getString(R.string.Unity_Ad_id), loadListener);
                    loadListener = new IUnityAdsLoadListener() {
                        @Override
                        public void onUnityAdsAdLoaded(String s) {
                            UnityAds.show((Activity) context, context.getString(R.string.Unity_Ad_id), new UnityAdsShowOptions(), showListener);

                        }

                        @Override
                        public void onUnityAdsFailedToLoad(String s, UnityAds.UnityAdsLoadError unityAdsLoadError, String s1) {

                        }
                    };

                    showListener = new IUnityAdsShowListener() {
                        @Override
                        public void onUnityAdsShowFailure(String s, UnityAds.UnityAdsShowError unityAdsShowError, String s1) {

                        }

                        @Override
                        public void onUnityAdsShowStart(String s) {

                        }

                        @Override
                        public void onUnityAdsShowClick(String s) {

                        }

                        @Override
                        public void onUnityAdsShowComplete(String s, UnityAds.UnityAdsShowCompletionState unityAdsShowCompletionState) {
                            check = true;
                            if (check) {
                               // Random r = new Random();
                                //int i1 = r.nextInt(max - min) + min;
                                String point = "5";
                                Add_Coins_(context,point,"Video credit");
                                check = false;

                            }
                        }
                    };
                }
                else if (offer.getType().equals("colony"))
                {
                    displayRewardVideoAd();
                }



            }
        });


    }

    @Override
    public int getItemCount() {
        return offer_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RoundedImageView img;
        TextView title,k;
        LinearLayout click;

        public ViewHolder(View itemView) {
            super(itemView);
             img = itemView.findViewById(R.id.img);
             title = itemView.findViewById(R.id.title);
             k = itemView.findViewById(R.id.k);
             click = itemView.findViewById(R.id.click);

        }
    }


    public void settings() {
        // showpDialog();
        JsonRequest stringRequest = new JsonRequest(Request.Method.POST,
                Base_Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                VolleyLog.d(ContentValues.TAG, "Response: " + response.toString());
                if (response != null) {
                    parseJsonFeed(response);


                    // Toast.makeText(MainActivity.this,response.toString(),Toast.LENGTH_LONG).show();
                }
                //hidepDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_LONG).show();
                //  hidepDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(ACCESS_KEY, ACCESS_Value);
                params.put("settings", "settings");
                return params;
            }
        };
        // Adding request to volley request queue
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
    private void parseJsonFeed(JSONObject response) {
        try {
            JSONArray feedArray = response.getJSONArray("set");
            for (int i = 0; i < feedArray.length(); i++) {
                JSONObject feedObj = (JSONObject) feedArray.get(i);
                //Toast.makeText(MainActivity.this,feedObj.getString("check_p"),Toast.LENGTH_LONG).show();
                String AG_WALLCODE = (feedObj.getString("AG_WALLCODE"));
                String check_ag = (feedObj.getString("check_ag"));
                if (check_ag.equals("0"))
                {
                    ADGET_WALL_id = AG_WALLCODE;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            //  listView.setVisibility(View.GONE);
            Toast.makeText(context,e.toString(),Toast.LENGTH_LONG).show();

        }
    }


    private void initRewardedAd() {
// Create and set a reward listener
        AdColony.setRewardListener(new AdColonyRewardListener() {
            @Override
            public void onReward(AdColonyReward reward) {
// Query reward object for info here
//here reward vid is seen by user
//you can use this listener inside activity also
                if(reward.success()){
                    String point = "5";
                    Toast.makeText(context.getApplicationContext(),"5 coins added to your wallet!",Toast.LENGTH_SHORT).show();
                    Add_Coins_(context,point,"Video credit");
                    check = false;
                }
                else{
                    Toast.makeText(context.getApplicationContext(),"Kindly watch full video to get reward!",Toast.LENGTH_SHORT).show();
                }
            }
        });
// Set up listener for interstitial ad callbacks. You only need to implement the callbacks
// that you care about. The only required callback is onRequestFilled, as this is the only
// way to get an ad object.
        rewardListener = new AdColonyInterstitialListener() {
            @Override
            public void onRequestFilled(AdColonyInterstitial adReward) {
// Ad passed back in request filled callback, ad can now be shown
                rewardAdColony = adReward;
                isRewardLoaded=true;
            }
            @Override
            public void onRequestNotFilled(AdColonyZone zone) {
            }
            @Override
            public void onOpened(AdColonyInterstitial ad) {
                super.onOpened(ad);
            }
            @Override
            public void onClosed(AdColonyInterstitial ad) {
                super.onClosed(ad);

                AdColony.requestInterstitial(context.getString(R.string.ADCOLONY_REWARD_ZONE_ID), rewardListener, rewardAdOptions);
            }
            @Override
            public void onClicked(AdColonyInterstitial ad) {
                super.onClicked(ad);
            }
            @Override
            public void onLeftApplication(AdColonyInterstitial ad) {
                super.onLeftApplication(ad);
            }
            @Override
            public void onExpiring(AdColonyInterstitial ad) {
                super.onExpiring(ad);
            }
        };
// Ad specific options to be sent with request
        rewardAdOptions = new AdColonyAdOptions()
                .enableConfirmationDialog(false)
                .enableResultsDialog(false);
        AdColony.requestInterstitial(context.getString(R.string.ADCOLONY_REWARD_ZONE_ID),rewardListener,rewardAdOptions);
    }

    public void displayRewardVideoAd() {
        if (rewardAdColony!=null && isRewardLoaded) {
            rewardAdColony.show();
            isRewardLoaded=false;
        }
        else {
            Toast.makeText(context.getApplicationContext(),"Reward Ad Is Not Loaded Yet or Request Not Filled",Toast.LENGTH_SHORT).show();
        }
    }

}



