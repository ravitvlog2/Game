package com.aadevelopers.cashking.csm;

import static android.content.ContentValues.TAG;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_KEY;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_Value;
import static com.aadevelopers.cashking.helper.Constatnt.Base_Url;
import static com.aadevelopers.cashking.helper.Constatnt.GameZone_Coins;
import static com.aadevelopers.cashking.helper.PrefManager.Add_Coins_;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;
import com.aadevelopers.cashking.R;
import com.aadevelopers.cashking.helper.AppController;
import com.aadevelopers.cashking.helper.JsonRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class PlayActivity extends AppCompatActivity {
    CircularProgressBar circularProgressBar;
    Float progress= 0f,maxpro = 60f;
    Boolean isover = false, limit = false, check_play = false;
    CustomTabsIntent customTabsIntent;
    String url;
    CardView close,close3,play3,play2;
    LinearLayout loading;
    ImageView cut;
    TextView mints,coins,title;
    CountDownTimer countDownTimer;
    int sec=0;
    int total_sec = 360; // in seconds
    int min = 60;
    //reward int
    int minuts,reward,time=60;
    RelativeLayout claim,first,second,third,main_page,play;
    CircleImageView img;
    int pro = 0;
    ProgressBar progressBar;

    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        first = findViewById(R.id.progress);
        second = findViewById(R.id.claim_layout);
        third = findViewById(R.id.warn);
        mints = findViewById(R.id.minuts);
        coins = findViewById(R.id.coins);
        play = findViewById(R.id.play);
        close = findViewById(R.id.close);
        close3 = findViewById(R.id.close3);
        play3 = findViewById(R.id.play3);
        claim = findViewById(R.id.claim);
        play2 = findViewById(R.id.play2);
        loading = findViewById(R.id.loading);
        cut = findViewById(R.id.cut);
        main_page = findViewById(R.id.main_page);
        img = findViewById(R.id.img);
        title = findViewById(R.id.title);
        progressBar = findViewById(R.id.progressBar);

        third.setVisibility(View.GONE);
        first.setVisibility(View.GONE);
        second.setVisibility(View.GONE);
        main_page.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);

        progressBar.setMax(total_sec);



        circularProgressBar = findViewById(R.id.PBar);
        circularProgressBar.setProgressWithAnimation(progress, 1000L); // =1s
        circularProgressBar.setProgressMax(maxpro);
        circularProgressBar.setRoundBorder(true);
        circularProgressBar.setStartAngle(-180f);
        circularProgressBar.setProgressDirection(CircularProgressBar.ProgressDirection.TO_RIGHT);

        getlist();

        count();
        Intent i = getIntent();
        url = i.getStringExtra("url");

        Glide.with(this).load(i.getStringExtra("image"))
                .apply(new RequestOptions().placeholder(R.mipmap.ic_launcher_round))
                .into(img);

        title.setText(i.getStringExtra("name"));


        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        customTabsIntent = builder.build();
        // customTabsIntent.launchUrl(this, Uri.parse(url));
        interstitialAd = new InterstitialAd(this, getResources().getString(R.string.interstitialAd));
        InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {

            }

            @Override
            public void onInterstitialDismissed(Ad ad) {

            }

            @Override
            public void onError(Ad ad, AdError adError) {

            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };

        interstitialAd.loadAd(
                interstitialAd.buildLoadAdConfig()
                        .withAdListener(interstitialAdListener)
                        .build());

        cut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd.isAdLoaded())
                {
                    interstitialAd.show();
                    finish();
                }else
                {
                    finish();
                }
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check_play=true;
                customTabsIntent.launchUrl(PlayActivity.this, Uri.parse(url));
                //third.setVisibility(View.GONE);
                // first.setVisibility(View.GONE);
                // second.setVisibility(View.GONE);
                main_page.setVisibility(View.GONE);
                loading.setVisibility(View.VISIBLE);
            }
        });
        play2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check_play=true;
                customTabsIntent.launchUrl(PlayActivity.this, Uri.parse(url));
                //third.setVisibility(View.GONE);
               // first.setVisibility(View.GONE);
               // second.setVisibility(View.GONE);
                main_page.setVisibility(View.GONE);
                loading.setVisibility(View.VISIBLE);

            }
        });
        play3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customTabsIntent.launchUrl(PlayActivity.this, Uri.parse(url));
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd.isAdLoaded())
                {
                    interstitialAd.show();
                    finish();
                }else
                {
                    finish();
                }

            }
        });
        close3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (interstitialAd.isAdLoaded())
                {
                    interstitialAd.show();
                    finish();
                }else
                {
                    finish();
                }
            }
        });
    }

    private void count() {

        int total_sec_current= total_sec-sec;
        total_sec_current=total_sec_current*1000;
        // Toast.makeText(PlayActivity.this, ""+total_sec_current, Toast.LENGTH_SHORT).show();

        countDownTimer =  new CountDownTimer(total_sec_current, 1000) {
            public void onFinish() {
                // When timer is finished
                // Execute your code here
                //Toast.makeText(PlayActivity.this, "Finished!", Toast.LENGTH_SHORT).show();
                isover = true;
            }

            public void onTick(long millisUntilFinished) {
                // millisUntilFinished    The amount of time until finished.

                if (!(pro >=total_sec))
                {
                    pro+=1;
                    progressBar.setProgress(pro);
                }
                if (!(sec >=min)) {
                    progress = progress + 1f;
                    circularProgressBar.setProgressWithAnimation(progress, 1000L); // =1s
                }
                sec = sec+1;
            }
        }.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (limit) {
            if (check_play) {
                if (!isover) {
                    count();
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        countDownTimer.cancel();
        if (limit) {
            if (check_play){
                check_play=false;
                if ((sec >= min)) {
                    main_page.setVisibility(View.VISIBLE);
                    loading.setVisibility(View.GONE);
                    minuts = sec/time;
                    reward = minuts*GameZone_Coins;
                    mints.setText(minuts+" min");
                    coins.setText(reward+"");

                    claim.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (interstitialAd.isAdLoaded()) {interstitialAd.show();}
                            Add_Coins_(PlayActivity.this,""+reward,"GameZone");

                        }
                    });



                }else
                {
                    //third.setVisibility(View.GONE);
                    //first.setVisibility(View.VISIBLE);
                   // second.setVisibility(View.GONE);
                    main_page.setVisibility(View.VISIBLE);
                    loading.setVisibility(View.GONE);
                }
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        countDownTimer.cancel();
    }


    public void getlist() {
        // showpDialog();
        JsonRequest stringRequest = new JsonRequest(Request.Method.POST,
                Base_Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                VolleyLog.d(TAG, "Response: " + response.toString());
                if (response != null) {
                    parseJsonFeed(response);
                    //Toast.makeText(getActivity(),response.toString(),Toast.LENGTH_LONG).show();
                }
                //hidepDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PlayActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                //  hidepDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(ACCESS_KEY, ACCESS_Value);
                params.put("check_zone", AppController.getInstance().getUsername());
                return params;
            }
        };
        // Adding request to volley request queue
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
    private void parseJsonFeed(JSONObject response) {
        try {
            if (response.getString("error").equals("false"))
            {
                //Toast.makeText(PlayActivity.this,response.getString("games").trim(),Toast.LENGTH_LONG).show();
                limit = true;
                check_play = true;
                customTabsIntent.launchUrl(this, Uri.parse(url));
            }else
            {
                limit = false;
                TextView text2 = findViewById(R.id.text2);
                text2.setText(response.getString("msg"));
                third.setVisibility(View.GONE);
                first.setVisibility(View.GONE);
                second.setVisibility(View.GONE);
                loading.setVisibility(View.GONE);
                main_page.setVisibility(View.VISIBLE);
                //Toast.makeText(PlayActivity.this,response.getString("msg"),Toast.LENGTH_LONG).show();
            }




        } catch (JSONException e) {
            e.printStackTrace();

            Toast.makeText(PlayActivity.this,e.toString(),Toast.LENGTH_LONG).show();

        }
    }

}
