package com.aadevelopers.cashking.csm;


import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_KEY;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_Value;
import static com.aadevelopers.cashking.helper.Constatnt.API;
import static com.aadevelopers.cashking.helper.Constatnt.Base_Url;
import static com.aadevelopers.cashking.helper.Constatnt.USERNAME;
import static com.aadevelopers.cashking.helper.PrefManager.setWindowFlag;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.ayetstudios.publishersdk.AyetSdk;
import com.ayetstudios.publishersdk.interfaces.DeductUserBalanceCallback;
import com.ayetstudios.publishersdk.interfaces.UserBalanceCallback;
import com.ayetstudios.publishersdk.messages.SdkUserBalance;
import com.facebook.ads.AudienceNetworkAds;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.UnityAds;
import com.aadevelopers.cashking.R;
import com.aadevelopers.cashking.helper.AppController;
import com.aadevelopers.cashking.helper.JsonRequest;
import com.aadevelopers.cashking.csm.fragment.FragmentProfile;
import com.aadevelopers.cashking.csm.fragment.FragmentRefer;
import com.aadevelopers.cashking.csm.fragment.LeaderBoardFragment;
import com.aadevelopers.cashking.csm.fragment.Main_Fragment;
import com.aadevelopers.cashking.csm.fragment.RewardFragment;

import org.json.JSONObject;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity implements MaxRewardedAdListener, IUnityAdsInitializationListener {
    //This is our viewPager
    FragmentRefer tournament_fragment;
    boolean canInstallPackage;
    private Boolean testMode = false;
    ChipNavigationBar chipNav;
    Boolean isBack = false;

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//Set Portrait
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        AppController.getInstance();
        UnityAds.initialize(getApplicationContext(), getString(R.string.Unity_GameID), testMode, this);
        loadFragment(new Main_Fragment());
        chipNav = findViewById(R.id.chipNav);
        chipNav.setItemSelected(R.id.play,true);


        AudienceNetworkAds.initialize(this);
      //  AppLovinSdk.getInstance(MainActivity.this).setMediationProvider( "max" );

        AppLovinSdk.initializeSdk(this, new AppLovinSdk.SdkInitializationListener() {
            @Override
            public void onSdkInitialized(final AppLovinSdkConfiguration configuration)
            {
                //Toast.makeText(MainActivity.this, configuration.toString(), Toast.LENGTH_SHORT).show();
                AppLovinSdk.getInstance(MainActivity.this).getSettings().setTestDeviceAdvertisingIds(Arrays.asList("2f7bcab5-934e-4455-9e3b-10calad1abe1"));

            }
        } );






        AyetSdk.init((Application) getApplicationContext(), AppController.getInstance().getId(), new UserBalanceCallback() { // UserBalanceCallback is optional if you want to manage balances on your servers
            @Override
            public void userBalanceChanged(SdkUserBalance sdkUserBalance) {
                Log.d("AyetSdk" , "userBalanceChanged - available balance: "+sdkUserBalance.getAvailableBalance()); // this is the new total available balance for the user
            }

            @Override
            public void userBalanceInitialized(SdkUserBalance sdkUserBalance) {
                Log.d("AyetSdk" , "SDK initialization successful");
                Log.d("AyetSdk" , "userBalanceInitialized - available balance: "+sdkUserBalance.getAvailableBalance()); // this is the total available balance for the user
                Log.d("AyetSdk" , "userBalanceInitialized - spent balance: "+sdkUserBalance.getSpentBalance()); // this is the total amount spent with "AyetSdk.deductUserBalance(..)"
                Log.d("AyetSdk" , "userBalanceInitialized - pending balance: "+sdkUserBalance.getPendingBalance()); // this is the amount currently pending for conversion (e.g. user still has offer requirements to meet)
            }

            @Override
            public void initializationFailed() {
                Log.d("AyetSdk", "initializationFailed - please check APP API KEY & internet connectivity");
            }
        });

        int amount=100;
        AyetSdk.deductUserBalance(MainActivity.this, amount, new DeductUserBalanceCallback() {
            @Override
            public void success() {

            }

            @Override
            public void failed() {
                Log.d("AyetSdk" , "deductUserBalance - failed");
                // this usually means that the user does not have sufficient balance in his account
            }
        });

         //Initializing the bottomNavigationView
       // AppController.transparentStatusAndNavigation(MainActivity.this);
        int notification_count =0;
        try{
            notification_count = Integer.parseInt(AppController.getInstance().getBadge());
        }catch (Exception e){

        }


        chipNav.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int i) {
                switch (i)
                {
                    case R.id.play:
                        loadFragment(new Main_Fragment());
                        break;
                    case R.id.battle:
                        loadFragment(new LeaderBoardFragment());
                        break;
                    case R.id.tournament:
                        loadFragment(new FragmentRefer());
                        loadFragment(tournament_fragment);
                        break;
                    case R.id.profile:
                        loadFragment(new FragmentProfile());
                        break;
                    case R.id.Rewards:
                        loadFragment(new RewardFragment());
                        break;
                }
            }
        });

        cjeck();

        //spin();
        time_update();

    }
    public static void change(int position,ViewPager viewPager){
        viewPager.setCurrentItem(position);
        
    }



   public void time_update(){
       int delay = 0; // delay for 0 sec.
       int period = 10000000; // repeat every 10 sec.
       Timer timer = new Timer();
       timer.scheduleAtFixedRate(new TimerTask()
       {
           public void run()
           {
               update_point();
           }
       }, delay, period);
   }
    private void update_point(){
        JsonRequest jsonReq = new JsonRequest(Request.Method.POST, Base_Url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (AppController.getInstance().authorize(response)) {

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();

                params.put(ACCESS_KEY, ACCESS_Value);
                params.put("user_point_update", API);
                params.put("fcm_id", "FirebaseInstanceId.getInstance().getToken()");
                params.put(USERNAME, AppController.getInstance().getUsername());
                return params;
            }
        };
        AppController.getInstance().getRequestQueue().getCache().clear();
        AppController.getInstance().addToRequestQueue(jsonReq);
       // toast(this,FirebaseInstanceId.getInstance().getToken());
    }

    public static void toast(Context context,String message){
        Toast.makeText(context,message,Toast.LENGTH_LONG).show();
    }

    private void cjeck(){
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            // this will request for permission when permission is not true
        }else{
            // Download code here
        }
    }
    @Override
    protected void onResume() {
        AppController.getInstance();
        super.onResume();

    }
    @Override
    protected void onPause() {
        super.onPause();
    }
    @Override
    protected void onDestroy() {
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRewardedVideoStarted(MaxAd ad) {

    }

    @Override
    public void onRewardedVideoCompleted(MaxAd ad) {

    }

    @Override
    public void onUserRewarded(MaxAd ad, MaxReward reward) {

    }

    @Override
    public void onAdLoaded(MaxAd ad) {

    }

    @Override
    public void onAdDisplayed(MaxAd ad) {

    }

    @Override
    public void onAdHidden(MaxAd ad) {

    }

    @Override
    public void onAdClicked(MaxAd ad) {

    }

    @Override
    public void onAdLoadFailed(String adUnitId, MaxError error) {

        Toast.makeText(this, error.getMessage(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onAdDisplayFailed(MaxAd ad, MaxError error) {

    }



    @Override
    public void onInitializationComplete() {

    }

    @Override
    public void onInitializationFailed(UnityAds.UnityAdsInitializationError unityAdsInitializationError, String s) {

    }




    @Override
    public void onBackPressed() {


        if (isBack.equals(false))
        {
            isBack = true;
            android.app.Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.fragment_dialog);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable
                    (Color.TRANSPARENT));

            Button no = dialog.findViewById(R.id.no);
            Button yes = dialog.findViewById(R.id.yes);

            yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                    System.exit(0);
                }
            });

            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                    isBack = false;
                }
            });
            dialog.setCancelable(false);

            dialog.show();


        }



/*        if (pressedTime + 2000 > System.currentTimeMillis()) {
            super.onBackPressed();
            finish();
        } else {
            Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
        pressedTime = System.currentTimeMillis();*/


    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.flFragment, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
