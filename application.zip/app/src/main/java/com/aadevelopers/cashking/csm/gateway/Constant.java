package com.aadevelopers.cashking.csm.gateway;

/**
 * Created by kamal_bunkar on 27-12-2017.
 */

public class Constant {

    public static final long API_CONNECTION_TIMEOUT = 1201;
    public static final long API_READ_TIMEOUT = 901;
    public static String TAG ="mainActivity", txnid ="txt12346",
            prodname ="WEB Buy Coin",
            merchantId ="7174458", merchantkey="Q95x4CBD";  //   first test key only
    public static final String BASE_URL =   "http://www.webseller.store/crazyone";   // https://www your domain .com/


}
