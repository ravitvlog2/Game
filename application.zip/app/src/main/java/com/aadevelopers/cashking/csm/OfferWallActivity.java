package com.aadevelopers.cashking.csm;

import static android.content.ContentValues.TAG;
import static com.aadevelopers.cashking.Activity_otp.randomAlphaNumeric;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_KEY;
import static com.aadevelopers.cashking.helper.Constatnt.ACCESS_Value;
import static com.aadevelopers.cashking.helper.Constatnt.Base_Url;
import static com.aadevelopers.cashking.helper.PrefManager.setWindowFlag;
import static com.aadevelopers.cashking.helper.PrefManager.user_points;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.adcolony.sdk.AdColony;
import com.adcolony.sdk.AdColonyAdOptions;
import com.adcolony.sdk.AdColonyInterstitial;
import com.adcolony.sdk.AdColonyInterstitialListener;
import com.adcolony.sdk.AdColonyReward;
import com.adcolony.sdk.AdColonyRewardListener;
import com.adcolony.sdk.AdColonyZone;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.ironsource.mediationsdk.IronSource;
import com.offertoro.sdk.OTOfferWallSettings;
import com.pollfish.Pollfish;
import com.pollfish.builder.Params;
import com.pollfish.callback.PollfishOpenedListener;
import com.pollfish.callback.PollfishSurveyNotAvailableListener;
import com.pollfish.callback.PollfishUserNotEligibleListener;
import com.pollfish.callback.PollfishUserRejectedSurveyListener;
import com.startapp.sdk.adsbase.StartAppAd;
import com.aadevelopers.cashking.R;
import com.aadevelopers.cashking.helper.AppController;
import com.aadevelopers.cashking.helper.JsonRequest;
import com.aadevelopers.cashking.csm.adapter.OfferWall_Adapter;
import com.aadevelopers.cashking.csm.model.OfferWall_Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OfferWallActivity extends AppCompatActivity {
    private OfferWall_Adapter offerWall_adapter;
    private List<OfferWall_Model> offers = new ArrayList<>();
    RecyclerView rv_offer;
    Params params;
    TextView title;
    ImageView back;
    StartAppAd startAppAd;
    AdColonyInterstitial rewardAdColony;
    Boolean isRewardLoaded = false;
    AdColonyInterstitialListener rewardListener;
    AdColonyAdOptions rewardAdOptions;
    TextView points;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        setContentView(R.layout.activity_offer_wall);
        AdColony.configure(this,getString(R.string.adcolony_app_id));
        AdColonyAdOptions options = new AdColonyAdOptions()
                .enableConfirmationDialog(true)
                .enableResultsDialog(true);

        points = findViewById(R.id.points);
        rv_offer = findViewById(R.id.rv_offer);
        title = findViewById(R.id.title);
        back = findViewById(R.id.back);

        IronSource.init(this, getString(R.string.iron_source_app_id), IronSource.AD_UNIT.OFFERWALL,IronSource.AD_UNIT.REWARDED_VIDEO);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });


        settings();


        Intent i = getIntent();

        try {
            JSONArray array = new JSONArray(i.getStringExtra("array"));
            for (int index=0; index < array.length(); index++)
            {
                JSONObject feedObj = (JSONObject) array.get(index);
                switch (i.getStringExtra("type"))
                {
                    case "o":
                        title.setText("OfferWalls");
                        if (feedObj.getString("offer_name").equals("adget") || feedObj.getString("offer_name").equals("toro") ||
                                feedObj.getString("offer_name").equals("ayet")||
                                feedObj.getString("offer_name").equals("iron_offer")
                    )
                        {
                            OfferWall_Model item = new OfferWall_Model(feedObj.getString("title"),feedObj.getString("sub"),
                                    feedObj.getString("image"),feedObj.getString("offer_name"));
                            offers.add(item);
                        }
                        break;
                    case "v":
                        title.setText("Videos");
                        if (feedObj.getString("offer_name").equals("fb") ||
                                feedObj.getString("offer_name").equals("iron") ||
                                feedObj.getString("offer_name").equals("unity") ||
                                feedObj.getString("offer_name").equals("start")
                                ||feedObj.getString("offer_name").equals("colony"))



                        {
                            OfferWall_Model item = new OfferWall_Model(feedObj.getString("title"),feedObj.getString("sub"),
                                    feedObj.getString("image"),feedObj.getString("offer_name"));
                            offers.add(item);
                        }

                }

            }

            offerWall_adapter = new OfferWall_Adapter(offers,OfferWallActivity.this);
            rv_offer.setLayoutManager(new LinearLayoutManager(OfferWallActivity.this));
            rv_offer.setAdapter(offerWall_adapter);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
        }

    }

    public void settings() {
        // showpDialog();
        JsonRequest stringRequest = new JsonRequest(Request.Method.POST,
                Base_Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                VolleyLog.d(TAG, "Response: " + response.toString());
                if (response != null) {
                    parseJsonFeed(response);


                    // Toast.makeText(MainActivity.this,response.toString(),Toast.LENGTH_LONG).show();
                }
                //hidepDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(OfferWallActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                //  hidepDialog();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(ACCESS_KEY, ACCESS_Value);
                params.put("settings", "settings");
                return params;
            }
        };
        // Adding request to volley request queue
        AppController.getInstance().addToRequestQueue(stringRequest);
    }
    private void parseJsonFeed(JSONObject response) {
        try {
            JSONArray feedArray = response.getJSONArray("set");

            //Toast.makeText(this,":"+feedArray.length() , Toast.LENGTH_SHORT).show();
            for (int i = 0; i < feedArray.length(); i++) {
                JSONObject feedObj = (JSONObject) feedArray.get(i);

                //Toast.makeText(MainActivity.this,feedObj.getString("check_p"),Toast.LENGTH_LONG).show();

                String OT_APP_ID = (feedObj.getString("OT_APP_ID"));
                String OT_KEY=(feedObj.getString("OT_KEY"));
                String PF_ID = (feedObj.getString("PF_ID"));
                String AG_WALLCODE = (feedObj.getString("AG_WALLCODE"));
                String check_ag = (feedObj.getString("check_ag"));
                String check_ot = (feedObj.getString("check_ot"));
                String check_p = (feedObj.getString("check_p"));

                if (check_ot.equals("0"))
                {
                    ot(OT_APP_ID,OT_KEY);
                }

                if (check_p.equals("0"))
                {
                    poll(PF_ID);
                }
            }



        } catch (JSONException e) {
            e.printStackTrace();
            //  listView.setVisibility(View.GONE);
            Toast.makeText(OfferWallActivity.this,e.toString(),Toast.LENGTH_LONG).show();

        }
    }

    public void ot(String OT_APP_ID, String OT_KEY) {
        OTOfferWallSettings.getInstance().configInit(OT_APP_ID,
                OT_KEY, AppController.getInstance().getUsername());

    }
    public void poll(String poll) {
        String code = randomAlphaNumeric(15);
        params = new Params.Builder(poll)
                .requestUUID(AppController.getInstance().getId())
                .rewardMode(true)
                .offerwallMode(true)
                .releaseMode(false)
                .pollfishSurveyNotAvailableListener(new PollfishSurveyNotAvailableListener() {
                    @Override
                    public void onPollfishSurveyNotAvailable() {
                        Toast.makeText(OfferWallActivity.this, "not available", Toast.LENGTH_SHORT).show();
                    }
                })
                .pollfishUserNotEligibleListener(new PollfishUserNotEligibleListener() {
                    @Override
                    public void onUserNotEligible() {
                        Toast.makeText(OfferWallActivity.this, "not available", Toast.LENGTH_SHORT).show();

                    }
                })
                .pollfishOpenedListener(new PollfishOpenedListener() {
                    @Override
                    public void onPollfishOpened() {
                        Toast.makeText(OfferWallActivity.this, "not available", Toast.LENGTH_SHORT).show();

                    }
                })
                .pollfishUserRejectedSurveyListener(new PollfishUserRejectedSurveyListener() {
                    @Override
                    public void onUserRejectedSurvey() {
                        Toast.makeText(OfferWallActivity.this, "not available", Toast.LENGTH_SHORT).show();

                    }
                })
                .signature(code)
                .build();

        Pollfish.initWith(this, params);
    }

    private void initRewardedAd() {
// Create and set a reward listener
        AdColony.setRewardListener(new AdColonyRewardListener() {
            @Override
            public void onReward(AdColonyReward reward) {
// Query reward object for info here
//here reward vid is seen by user
//you can use this listener inside activity also
                if(reward.success()){
                    Toast.makeText(getApplicationContext(),"Reward Earned",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"Reward Cancelled",Toast.LENGTH_SHORT).show();
                }
            }
        });
// Set up listener for interstitial ad callbacks. You only need to implement the callbacks
// that you care about. The only required callback is onRequestFilled, as this is the only
// way to get an ad object.
        rewardListener = new AdColonyInterstitialListener() {
            @Override
            public void onRequestFilled(AdColonyInterstitial adReward) {
// Ad passed back in request filled callback, ad can now be shown
                rewardAdColony = adReward;
                isRewardLoaded=true;
            }
            @Override
            public void onRequestNotFilled(AdColonyZone zone) {
            }
            @Override
            public void onOpened(AdColonyInterstitial ad) {
                super.onOpened(ad);
            }
            @Override
            public void onClosed(AdColonyInterstitial ad) {
                super.onClosed(ad);
//request new reward on close
                AdColony.requestInterstitial(getString(R.string.ADCOLONY_REWARD_ZONE_ID), rewardListener, rewardAdOptions);
            }
            @Override
            public void onClicked(AdColonyInterstitial ad) {
                super.onClicked(ad);
            }
            @Override
            public void onLeftApplication(AdColonyInterstitial ad) {
                super.onLeftApplication(ad);
            }
            @Override
            public void onExpiring(AdColonyInterstitial ad) {
                super.onExpiring(ad);
            }
        };
// Ad specific options to be sent with request
        rewardAdOptions = new AdColonyAdOptions()
                .enableConfirmationDialog(false)
                .enableResultsDialog(false);
        AdColony.requestInterstitial(getString(R.string.ADCOLONY_REWARD_ZONE_ID),rewardListener,rewardAdOptions);
    }

    @Override
    protected void onResume() {
        super.onResume();
        user_points(points);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("WORKAROUND_FOR_BUG_19917_KEY", "WORKAROUND_FOR_BUG_19917_VALUE");
        super.onSaveInstanceState(outState);
    }


}