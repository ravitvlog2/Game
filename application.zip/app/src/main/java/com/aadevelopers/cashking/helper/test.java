 package com.aadevelopers.cashking.helper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.aadevelopers.cashking.R;

 public class test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
    }
}